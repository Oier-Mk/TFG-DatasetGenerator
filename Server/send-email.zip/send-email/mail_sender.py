from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
from dotenv import dotenv_values

config = dotenv_values(".env")

conf = ConnectionConfig(
    MAIL_USERNAME = config["MAIL_USERNAME"],
    MAIL_PASSWORD = config["MAIL_PASSWORD"],
    MAIL_FROM = config["MAIL_FROM"],
    MAIL_PORT = 587,
    MAIL_SERVER = "smtp.gmail.com",
    MAIL_FROM_NAME="ds.generator",
    MAIL_STARTTLS = True,
    MAIL_SSL_TLS = False,
    USE_CREDENTIALS = True,
    VALIDATE_CERTS = True
)

async def send_email(receiver, subject, body):
    try:
        message = MessageSchema(
            subject=subject,
            recipients=[receiver],
            body=body,
            subtype='html',
        )
        fm = FastMail(conf)
        await fm.send_message(message)    
        return 1
    except Exception as e: 
        print(e.__traceback__)
        return 0

