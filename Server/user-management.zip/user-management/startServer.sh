cd /Users/mentxaka/Desktop/user-management/
uvicorn main:app --reload
