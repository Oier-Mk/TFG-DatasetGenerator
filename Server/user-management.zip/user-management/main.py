from fastapi import FastAPI, Request, Form, Response, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path
from async_generator import asynccontextmanager
from sessions import *

users = {}
users["oime3564@gmail.com"] = ["Oier", "oime3564@gmail.com", "1234"]
users["oime6435@gmail.com"] = ["Oier", "oime6435@gmail.com", "1234"]

from uuid import uuid4

app = FastAPI()

app.mount(
    "/static",
    StaticFiles(directory=Path(__file__).parent.absolute() / "static"),
    name="static",
)

templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request, session_data: SessionData = Depends(verifier)):
    name = "Guest"
    try: name = session_data.username
    except: pass
    return templates.TemplateResponse("home.html", {"request": request , "users_name": name})
    
@app.get("/login/", response_class=HTMLResponse)
async def login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})  

@app.get("/register/", response_class=HTMLResponse)
async def register(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})    

@app.post("/login/", response_class=HTMLResponse)
async def check_login(request: Request, response: Response, email: str = Form(...), password: str = Form(...)):
    print(email +" - "+ password)
    if users[email]:
        if(users[email][2] == password): 
            session = uuid4()
            data = SessionData(username=email)
            await backend.create(session, data)
            cookie.attach_to_response(response, session)
            return "User "+ data.username +" already exists, logging in..."
        else: return "User "+ email +" already exists, wrong password"
    else:
        return "User "+ email +" does not exist"
    
@app.post("/register/", response_class=HTMLResponse)
async def check_register(request: Request, response: Response, username: str = Form(...), email: str = Form(...), password: str = Form(...), confirm_password: str = Form(...)):
    print(username +" - "+ email +" - "+ password +" - "+ confirm_password)
    if users[email]:
        if(users[email][2] == password): 
            session = uuid4()
            data = SessionData(username=email)
            await backend.create(session, data)
            cookie.attach_to_response(response, session)
            return "User "+ data.username +" exists, logging in..."
        else: return "User "+ email +" exists, wrong password"
    else:
        users[email] = [username, email, password]
        print(users)
        session = uuid4()
        data = SessionData(username=email)
        await backend.create(session, data)
        cookie.attach_to_response(response, session)
        return f"created account for {data.username}"

@app.get("/shop/", dependencies=[Depends(cookie)])
async def displayShop(request: Request, session_data: SessionData = Depends(verifier)):
    return templates.TemplateResponse("shop.html", {"request": request, "session_data": session_data})

basket = []

@app.post("/shop/", dependencies=[Depends(cookie)])
async def processShop(session_data: SessionData = Depends(verifier), product: str = Form(...), quantity: str = Form(...)):
    basket.append((session_data.username,[product, quantity]))
    print(basket)

@app.get("/logout/")
async def del_session(response: Response, session_id: UUID = Depends(cookie)):
    try:
        await backend.delete(session_id)
        cookie.delete_from_response(response)
        return "deleted session"
    except KeyError:
        return "session not found"